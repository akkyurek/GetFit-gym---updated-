(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_5a235e39._.css",
  "static/chunks/node_modules_d7769b39._.js",
  "static/chunks/node_modules_@payloadcms_ui_dist_exports_client_chunk-AZDI6MW4_620fa4d6.js",
  "static/chunks/node_modules_@payloadcms_ui_dist_exports_client_index_23213770.js",
  "static/chunks/node_modules_@payloadcms_ui_dist_exports_client_9d2ad455._.js",
  "static/chunks/node_modules_@payloadcms_ui_dist_exports_shared_index_aa629bb0.js",
  "static/chunks/node_modules_@payloadcms_ui_dist_44e22e6e._.js",
  "static/chunks/node_modules_date-fns_3162c05f._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_f77289f1._.js",
  "static/chunks/node_modules_@dnd-kit_core_dist_core_esm_3ed85ea0.js",
  "static/chunks/72b6d_ajv_dist_ef5a4de1._.js",
  "static/chunks/node_modules_@payloadcms_next_dist_71c0368b._.js",
  "static/chunks/node_modules_0151dedf._.js"
],
    source: "dynamic"
});
