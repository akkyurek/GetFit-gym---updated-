'use client'
import { motion } from 'framer-motion'


export default function Home() {
return (
<motion.section
initial={{ opacity: 0, y: 40 }}
animate={{ opacity: 1, y: 0 }}
className="min-h-screen flex items-center justify-center"
>
<div className="text-center">
<h1 className="text-6xl font-bold text-primary">GetFit Gym</h1>
<p className="mt-4 text-gray-400">Train Hard. Stay Fit. Never Quit.</p>
</div>
</motion.section>
)
}