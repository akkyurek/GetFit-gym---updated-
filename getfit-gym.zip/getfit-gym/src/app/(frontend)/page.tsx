

import Hero from './components/Hero'
import Reveal from './components/Reveal'


export default function HomePage() {
return (
<main>
<Hero />


<section className="py-20 px-8 grid md:grid-cols-3 gap-8">
{["Modern Equipment", "Certified Trainers", "Flexible Timings"].map((item, i) => (
<Reveal key={i}>
<div className="bg-gray-900 p-6 rounded-2xl text-center">
<h3 className="text-2xl font-semibold mb-2">{item}</h3>
<p className="text-gray-400">Train smarter with world-class facilities.</p>
</div>
</Reveal>
))}
</section>
</main>
)
}