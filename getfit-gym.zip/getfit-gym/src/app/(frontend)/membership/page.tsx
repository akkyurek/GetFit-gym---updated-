

'use client'
import { motion } from 'framer-motion'


const plans = [
{ name: 'Basic', price: 'PKR 3,000 / month', features: ['Gym Access', 'Cardio'] },
{ name: 'Standard', price: 'PKR 6,000 / month', features: ['Gym + Weights', 'Trainer Support'] },
{ name: 'Premium', price: 'PKR 10,000 / month', features: ['Personal Trainer', 'Diet Plan'] }
]


export default function MembershipPage() {
return (
<div className="min-h-screen px-8 py-16">
<h2 className="text-4xl font-bold text-center mb-12">Membership Plans</h2>


<div className="grid md:grid-cols-3 gap-8">
{plans.map((plan, i) => (
<motion.div
key={i}
whileHover={{ scale: 1.05 }}
className="bg-gray-900 p-6 rounded-2xl shadow-xl"
>
<h3 className="text-2xl font-semibold mb-2">{plan.name}</h3>
<p className="text-red-500 text-xl mb-4">{plan.price}</p>
<ul className="text-gray-400 space-y-2">
{plan.features.map((f, idx) => (
<li key={idx}>✔ {f}</li>
))}
</ul>
</motion.div>
))}
</div>
</div>
)
}