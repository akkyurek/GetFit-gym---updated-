'use client'
import { motion } from 'framer-motion'
import Link from 'next/link'


export default function Hero() {
return (
<section className="min-h-screen flex flex-col justify-center items-center text-center px-6">
<motion.h1
initial={{ y: 40, opacity: 0 }}
animate={{ y: 0, opacity: 1 }}
transition={{ duration: 0.8 }}
className="text-6xl font-extrabold mb-6"
>
GetFit Gym
</motion.h1>


<motion.p
initial={{ y: 20, opacity: 0 }}
animate={{ y: 0, opacity: 1 }}
transition={{ delay: 0.3 }}
className="text-gray-400 max-w-xl mb-10"
>
Stronger every day. Join the gym that transforms effort into results.
</motion.p>


<motion.div
initial={{ scale: 0.8, opacity: 0 }}
animate={{ scale: 1, opacity: 1 }}
transition={{ delay: 0.6 }}
className="flex gap-4"
>
<Link href="/membership" className="bg-red-600 px-8 py-4 rounded-2xl hover:bg-red-700">
Join Now
</Link>
<Link href="/about" className="border px-8 py-4 rounded-2xl">
Learn More
</Link>
</motion.div>
</section>
)
}